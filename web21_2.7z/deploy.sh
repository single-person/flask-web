# 代码更新
git pull


# 重启服务器
service supervisor restart
service nginx restart

echo 'deploy success'